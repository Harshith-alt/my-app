-- Seed data for Military Asset Management System

-- Insert equipment types
INSERT INTO equipment_types (name, category, description) VALUES
('M4A1 Carbine', 'Weapons', 'Standard issue assault rifle'),
('M9 Pistol', 'Weapons', 'Standard issue sidearm'),
('HMMWV', 'Vehicles', 'High Mobility Multipurpose Wheeled Vehicle'),
('M1A2 Abrams', 'Vehicles', 'Main battle tank'),
('Night Vision Goggles', 'Equipment', 'AN/PVS-14 night vision device'),
('Body Armor', 'Equipment', 'Interceptor Body Armor system'),
('Radio Equipment', 'Communications', 'AN/PRC-152 tactical radio'),
('Medical Kit', 'Medical', 'Combat medic bag'),
('Ammunition 5.56mm', 'Ammunition', '5.56×45mm NATO ammunition'),
('Ammunition 9mm', 'Ammunition', '9×19mm Parabellum ammunition');

-- Insert military bases
INSERT INTO bases (name, location) VALUES
('Fort Liberty', 'North Carolina, USA'),
('Camp Pendleton', 'California, USA'),
('Fort Hood', 'Texas, USA'),
('Norfolk Naval Base', 'Virginia, USA'),
('Ramstein Air Base', 'Germany');

-- Insert initial admin user (password: admin123)
INSERT INTO users (username, email, password_hash, role, full_name) VALUES
('admin', 'admin@military.gov', '$2b$10$rQZ9QmjKjKjKjKjKjKjKjOeJ9QmjKjKjKjKjKjKjKjKjKjKjKjKjK', 'admin', 'System Administrator');

-- Insert base commanders
INSERT INTO users (username, email, password_hash, role, base_id, full_name) VALUES
('cmd_liberty', 'commander.liberty@military.gov', '$2b$10$rQZ9QmjKjKjKjKjKjKjKjOeJ9QmjKjKjKjKjKjKjKjKjKjKjKjKjK', 'base_commander', 1, 'Colonel John Smith'),
('cmd_pendleton', 'commander.pendleton@military.gov', '$2b$10$rQZ9QmjKjKjKjKjKjKjKjOeJ9QmjKjKjKjKjKjKjKjKjKjKjKjKjK', 'base_commander', 2, 'Colonel Sarah Johnson'),
('cmd_hood', 'commander.hood@military.gov', '$2b$10$rQZ9QmjKjKjKjKjKjKjKjOeJ9QmjKjKjKjKjKjKjKjKjKjKjKjKjK', 'base_commander', 3, 'Colonel Michael Davis');

-- Insert logistics officers
INSERT INTO users (username, email, password_hash, role, base_id, full_name) VALUES
('log_liberty', 'logistics.liberty@military.gov', '$2b$10$rQZ9QmjKjKjKjKjKjKjKjOeJ9QmjKjKjKjKjKjKjKjKjKjKjKjKjK', 'logistics_officer', 1, 'Major Robert Wilson'),
('log_pendleton', 'logistics.pendleton@military.gov', '$2b$10$rQZ9QmjKjKjKjKjKjKjKjOeJ9QmjKjKjKjKjKjKjKjKjKjKjKjKjK', 'logistics_officer', 2, 'Major Lisa Anderson'),
('log_hood', 'logistics.hood@military.gov', '$2b$10$rQZ9QmjKjKjKjKjKjKjKjOeJ9QmjKjKjKjKjKjKjKjKjKjKjKjKjK', 'logistics_officer', 3, 'Major David Brown');

-- Update base commanders
UPDATE bases SET commander_id = 2 WHERE id = 1;
UPDATE bases SET commander_id = 3 WHERE id = 2;
UPDATE bases SET commander_id = 4 WHERE id = 3;

-- Insert sample assets
INSERT INTO assets (serial_number, equipment_type_id, current_base_id, purchase_date, purchase_price) VALUES
('M4-001-2024', 1, 1, '2024-01-15', 1200.00),
('M4-002-2024', 1, 1, '2024-01-15', 1200.00),
('M4-003-2024', 1, 2, '2024-01-20', 1200.00),
('M9-001-2024', 2, 1, '2024-02-01', 600.00),
('M9-002-2024', 2, 2, '2024-02-01', 600.00),
('HMMWV-001-2024', 3, 1, '2024-01-10', 85000.00),
('HMMWV-002-2024', 3, 3, '2024-01-12', 85000.00),
('NVG-001-2024', 5, 1, '2024-03-01', 4500.00),
('NVG-002-2024', 5, 2, '2024-03-01', 4500.00),
('BA-001-2024', 6, 1, '2024-02-15', 800.00);

-- Insert sample purchases
INSERT INTO purchases (base_id, equipment_type_id, quantity, unit_price, total_amount, supplier, purchase_date, purchase_order_number, created_by) VALUES
(1, 1, 50, 1200.00, 60000.00, 'Colt Defense LLC', '2024-01-15', 'PO-2024-001', 1),
(1, 2, 25, 600.00, 15000.00, 'Beretta USA', '2024-02-01', 'PO-2024-002', 1),
(2, 1, 30, 1200.00, 36000.00, 'Colt Defense LLC', '2024-01-20', 'PO-2024-003', 1),
(1, 3, 5, 85000.00, 425000.00, 'AM General', '2024-01-10', 'PO-2024-004', 1),
(3, 3, 3, 85000.00, 255000.00, 'AM General', '2024-01-12', 'PO-2024-005', 1);

-- Insert sample transfers
INSERT INTO transfers (from_base_id, to_base_id, equipment_type_id, quantity, transfer_date, reason, status, requested_by, approved_by) VALUES
(1, 2, 1, 10, '2024-03-01', 'Operational requirement', 'completed', 5, 2),
(2, 3, 2, 5, '2024-03-15', 'Training exercise', 'completed', 6, 3),
(1, 3, 5, 3, '2024-04-01', 'Mission support', 'pending', 5, NULL);

-- Insert sample assignments
INSERT INTO assignments (asset_id, assigned_to_name, assigned_to_rank, assigned_to_unit, assignment_date, assignment_reason, assigned_by) VALUES
(1, 'Sergeant First Class Johnson', 'SFC', '1st Infantry Division', '2024-02-01', 'Training exercise', 2),
(4, 'Staff Sergeant Williams', 'SSG', '2nd Armored Division', '2024-02-15', 'Operational deployment', 2),
(8, 'Corporal Davis', 'CPL', 'Special Operations', '2024-03-01', 'Night operations', 3);

-- Insert sample expenditures
INSERT INTO expenditures (asset_id, expenditure_date, expenditure_reason, expenditure_type, authorized_by) VALUES
(2, '2024-03-20', 'Training ammunition expenditure', 'training', 2),
(5, '2024-04-01', 'Operational use', 'operation', 3);
