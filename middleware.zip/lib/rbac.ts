export type Role = "admin" | "base_commander" | "logistics_officer"

export interface Permission {
  resource: string
  action: string
}

export const rolePermissions: Record<Role, Permission[]> = {
  admin: [
    { resource: "dashboard", action: "read" },
    { resource: "purchases", action: "read" },
    { resource: "purchases", action: "write" },
    { resource: "transfers", action: "read" },
    { resource: "transfers", action: "write" },
    { resource: "assignments", action: "read" },
    { resource: "assignments", action: "write" },
    { resource: "users", action: "read" },
    { resource: "users", action: "write" },
    { resource: "bases", action: "read" },
    { resource: "bases", action: "write" },
  ],
  base_commander: [
    { resource: "dashboard", action: "read" },
    { resource: "purchases", action: "read" },
    { resource: "purchases", action: "write" },
    { resource: "transfers", action: "read" },
    { resource: "transfers", action: "write" },
    { resource: "assignments", action: "read" },
    { resource: "assignments", action: "write" },
  ],
  logistics_officer: [
    { resource: "dashboard", action: "read" },
    { resource: "purchases", action: "read" },
    { resource: "purchases", action: "write" },
    { resource: "transfers", action: "read" },
    { resource: "transfers", action: "write" },
  ],
}

export function hasPermission(role: Role, resource: string, action: string): boolean {
  const permissions = rolePermissions[role] || []
  return permissions.some((p) => p.resource === resource && p.action === action)
}

export function canAccessBase(userRole: Role, userBaseId: string | null, targetBaseId: string): boolean {
  if (userRole === "admin") return true
  if (userRole === "base_commander" || userRole === "logistics_officer") {
    return userBaseId === targetBaseId
  }
  return false
}
