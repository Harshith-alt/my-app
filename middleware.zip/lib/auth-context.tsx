"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

interface User {
  id: string
  username: string
  email: string
  name: string
  role: string
  baseId?: string
}

interface AuthContextType {
  user: User | null
  login: (username: string, password: string) => Promise<boolean>
  logout: () => void
  loading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Mock user data
const users = [
  {
    id: "1",
    username: "admin",
    email: "admin@military.gov",
    password: "admin123",
    role: "admin",
    name: "System Administrator",
    baseId: undefined,
  },
  {
    id: "2",
    username: "cmd_liberty",
    email: "commander.liberty@military.gov",
    password: "admin123",
    role: "base_commander",
    name: "Colonel John Smith",
    baseId: "1",
  },
  {
    id: "5",
    username: "log_liberty",
    email: "logistics.liberty@military.gov",
    password: "admin123",
    role: "logistics_officer",
    name: "Major Robert Wilson",
    baseId: "1",
  },
]

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check for stored session on mount
    const storedUser = localStorage.getItem("auth-user")
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser))
      } catch (error) {
        localStorage.removeItem("auth-user")
      }
    }
    setLoading(false)
  }, [])

  const login = async (username: string, password: string): Promise<boolean> => {
    const foundUser = users.find((u) => u.username === username && u.password === password)

    if (foundUser) {
      const userSession = {
        id: foundUser.id,
        username: foundUser.username,
        email: foundUser.email,
        name: foundUser.name,
        role: foundUser.role,
        baseId: foundUser.baseId,
      }

      setUser(userSession)
      localStorage.setItem("auth-user", JSON.stringify(userSession))
      return true
    }

    return false
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("auth-user")
  }

  return <AuthContext.Provider value={{ user, login, logout, loading }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
