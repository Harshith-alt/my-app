export interface Base {
  id: string
  name: string
  location: string
  commanderId?: string
}

export interface EquipmentType {
  id: string
  name: string
  category: string
  description: string
}

export interface Asset {
  id: string
  serialNumber: string
  equipmentTypeId: string
  currentBaseId: string
  status: "available" | "assigned" | "expended" | "maintenance"
  purchaseDate: string
  purchasePrice: number
}

export interface Purchase {
  id: string
  baseId: string
  equipmentTypeId: string
  quantity: number
  unitPrice: number
  totalAmount: number
  supplier: string
  purchaseDate: string
  purchaseOrderNumber: string
  createdBy: string
}

export interface Transfer {
  id: string
  fromBaseId: string
  toBaseId: string
  equipmentTypeId: string
  quantity: number
  transferDate: string
  reason: string
  status: "pending" | "in_transit" | "completed" | "cancelled"
  requestedBy: string
  approvedBy?: string
}

export interface Assignment {
  id: string
  assetId: string
  assignedToName: string
  assignedToRank: string
  assignedToUnit: string
  assignmentDate: string
  expectedReturnDate?: string
  actualReturnDate?: string
  assignmentReason: string
  status: "active" | "returned" | "overdue"
  assignedBy: string
}

export interface Expenditure {
  id: string
  assetId: string
  expenditureDate: string
  expenditureReason: string
  expenditureType: "training" | "operation" | "maintenance" | "disposal" | "lost" | "damaged"
  authorizedBy: string
}

// Mock data
export const bases: Base[] = [
  { id: "1", name: "Fort Liberty", location: "North Carolina, USA", commanderId: "2" },
  { id: "2", name: "Camp Pendleton", location: "California, USA", commanderId: "3" },
  { id: "3", name: "Fort Hood", location: "Texas, USA", commanderId: "4" },
  { id: "4", name: "Norfolk Naval Base", location: "Virginia, USA" },
  { id: "5", name: "Ramstein Air Base", location: "Germany" },
]

export const equipmentTypes: EquipmentType[] = [
  { id: "1", name: "M4A1 Carbine", category: "Weapons", description: "Standard issue assault rifle" },
  { id: "2", name: "M9 Pistol", category: "Weapons", description: "Standard issue sidearm" },
  { id: "3", name: "HMMWV", category: "Vehicles", description: "High Mobility Multipurpose Wheeled Vehicle" },
  { id: "4", name: "M1A2 Abrams", category: "Vehicles", description: "Main battle tank" },
  { id: "5", name: "Night Vision Goggles", category: "Equipment", description: "AN/PVS-14 night vision device" },
  { id: "6", name: "Body Armor", category: "Equipment", description: "Interceptor Body Armor system" },
  { id: "7", name: "Radio Equipment", category: "Communications", description: "AN/PRC-152 tactical radio" },
  { id: "8", name: "Medical Kit", category: "Medical", description: "Combat medic bag" },
  { id: "9", name: "Ammunition 5.56mm", category: "Ammunition", description: "5.56×45mm NATO ammunition" },
  { id: "10", name: "Ammunition 9mm", category: "Ammunition", description: "9×19mm Parabellum ammunition" },
]

export const purchases: Purchase[] = [
  {
    id: "1",
    baseId: "1",
    equipmentTypeId: "1",
    quantity: 50,
    unitPrice: 1200,
    totalAmount: 60000,
    supplier: "Colt Defense LLC",
    purchaseDate: "2024-01-15",
    purchaseOrderNumber: "PO-2024-001",
    createdBy: "1",
  },
  {
    id: "2",
    baseId: "1",
    equipmentTypeId: "2",
    quantity: 25,
    unitPrice: 600,
    totalAmount: 15000,
    supplier: "Beretta USA",
    purchaseDate: "2024-02-01",
    purchaseOrderNumber: "PO-2024-002",
    createdBy: "1",
  },
  {
    id: "3",
    baseId: "2",
    equipmentTypeId: "1",
    quantity: 30,
    unitPrice: 1200,
    totalAmount: 36000,
    supplier: "Colt Defense LLC",
    purchaseDate: "2024-01-20",
    purchaseOrderNumber: "PO-2024-003",
    createdBy: "1",
  },
]

export const transfers: Transfer[] = [
  {
    id: "1",
    fromBaseId: "1",
    toBaseId: "2",
    equipmentTypeId: "1",
    quantity: 10,
    transferDate: "2024-03-01",
    reason: "Operational requirement",
    status: "completed",
    requestedBy: "5",
    approvedBy: "2",
  },
  {
    id: "2",
    fromBaseId: "2",
    toBaseId: "3",
    equipmentTypeId: "2",
    quantity: 5,
    transferDate: "2024-03-15",
    reason: "Training exercise",
    status: "completed",
    requestedBy: "6",
    approvedBy: "3",
  },
  {
    id: "3",
    fromBaseId: "1",
    toBaseId: "3",
    equipmentTypeId: "5",
    quantity: 3,
    transferDate: "2024-04-01",
    reason: "Mission support",
    status: "pending",
    requestedBy: "5",
  },
]

export const assignments: Assignment[] = [
  {
    id: "1",
    assetId: "1",
    assignedToName: "Sergeant First Class Johnson",
    assignedToRank: "SFC",
    assignedToUnit: "1st Infantry Division",
    assignmentDate: "2024-02-01",
    assignmentReason: "Training exercise",
    status: "active",
    assignedBy: "2",
  },
  {
    id: "2",
    assetId: "4",
    assignedToName: "Staff Sergeant Williams",
    assignedToRank: "SSG",
    assignedToUnit: "2nd Armored Division",
    assignmentDate: "2024-02-15",
    assignmentReason: "Operational deployment",
    status: "active",
    assignedBy: "2",
  },
]

export const expenditures: Expenditure[] = [
  {
    id: "1",
    assetId: "2",
    expenditureDate: "2024-03-20",
    expenditureReason: "Training ammunition expenditure",
    expenditureType: "training",
    authorizedBy: "2",
  },
  {
    id: "2",
    assetId: "5",
    expenditureDate: "2024-04-01",
    expenditureReason: "Operational use",
    expenditureType: "operation",
    authorizedBy: "3",
  },
]
