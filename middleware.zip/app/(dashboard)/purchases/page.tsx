"use client"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Plus, Search } from "lucide-react"
import { bases, equipmentTypes, purchases } from "@/lib/mock-data"
import { hasPermission } from "@/lib/rbac"

export default function PurchasesPage() {
  const { user } = useAuth()
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedBase, setSelectedBase] = useState<string>("all")
  const [selectedEquipmentType, setSelectedEquipmentType] = useState<string>("all")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [newPurchase, setNewPurchase] = useState({
    baseId: "",
    equipmentTypeId: "",
    quantity: "",
    unitPrice: "",
    supplier: "",
    purchaseDate: "",
    purchaseOrderNumber: "",
  })

  // Check permissions
  const canWrite = hasPermission(user?.role as any, "purchases", "write")

  // Filter purchases based on user role and permissions
  const filteredPurchases = purchases.filter((purchase) => {
    // Role-based filtering
    if (user?.role !== "admin" && user?.baseId) {
      if (purchase.baseId !== user.baseId) return false
    }

    // Search filter
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase()
      const equipmentType = equipmentTypes.find((et) => et.id === purchase.equipmentTypeId)
      const base = bases.find((b) => b.id === purchase.baseId)

      if (
        !purchase.supplier.toLowerCase().includes(searchLower) &&
        !purchase.purchaseOrderNumber.toLowerCase().includes(searchLower) &&
        !equipmentType?.name.toLowerCase().includes(searchLower) &&
        !base?.name.toLowerCase().includes(searchLower)
      ) {
        return false
      }
    }

    // Base filter
    if (selectedBase !== "all" && purchase.baseId !== selectedBase) {
      return false
    }

    // Equipment type filter
    if (selectedEquipmentType !== "all" && purchase.equipmentTypeId !== selectedEquipmentType) {
      return false
    }

    return true
  })

  const handleAddPurchase = () => {
    // In a real app, this would make an API call
    console.log("Adding purchase:", newPurchase)
    setIsAddDialogOpen(false)
    setNewPurchase({
      baseId: "",
      equipmentTypeId: "",
      quantity: "",
      unitPrice: "",
      supplier: "",
      purchaseDate: "",
      purchaseOrderNumber: "",
    })
  }

  // Get available bases based on user role
  const availableBases = user?.role === "admin" ? bases : bases.filter((base) => base.id === user?.baseId)

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Purchases</h1>
          <p className="text-muted-foreground">Manage asset purchases and procurement records</p>
        </div>
        {canWrite && (
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Purchase
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Add New Purchase</DialogTitle>
                <DialogDescription>Record a new asset purchase for your base</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="base">Base</Label>
                    <Select
                      value={newPurchase.baseId}
                      onValueChange={(value) => setNewPurchase({ ...newPurchase, baseId: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select base" />
                      </SelectTrigger>
                      <SelectContent>
                        {availableBases.map((base) => (
                          <SelectItem key={base.id} value={base.id}>
                            {base.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="equipment">Equipment Type</Label>
                    <Select
                      value={newPurchase.equipmentTypeId}
                      onValueChange={(value) => setNewPurchase({ ...newPurchase, equipmentTypeId: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select equipment" />
                      </SelectTrigger>
                      <SelectContent>
                        {equipmentTypes.map((type) => (
                          <SelectItem key={type.id} value={type.id}>
                            {type.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="quantity">Quantity</Label>
                    <Input
                      id="quantity"
                      type="number"
                      value={newPurchase.quantity}
                      onChange={(e) => setNewPurchase({ ...newPurchase, quantity: e.target.value })}
                      placeholder="Enter quantity"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="unitPrice">Unit Price ($)</Label>
                    <Input
                      id="unitPrice"
                      type="number"
                      step="0.01"
                      value={newPurchase.unitPrice}
                      onChange={(e) => setNewPurchase({ ...newPurchase, unitPrice: e.target.value })}
                      placeholder="Enter unit price"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="supplier">Supplier</Label>
                  <Input
                    id="supplier"
                    value={newPurchase.supplier}
                    onChange={(e) => setNewPurchase({ ...newPurchase, supplier: e.target.value })}
                    placeholder="Enter supplier name"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="purchaseDate">Purchase Date</Label>
                    <Input
                      id="purchaseDate"
                      type="date"
                      value={newPurchase.purchaseDate}
                      onChange={(e) => setNewPurchase({ ...newPurchase, purchaseDate: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="poNumber">PO Number</Label>
                    <Input
                      id="poNumber"
                      value={newPurchase.purchaseOrderNumber}
                      onChange={(e) => setNewPurchase({ ...newPurchase, purchaseOrderNumber: e.target.value })}
                      placeholder="Purchase order number"
                    />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button type="submit" onClick={handleAddPurchase}>
                  Add Purchase
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Filters</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search purchases..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={selectedBase} onValueChange={setSelectedBase}>
              <SelectTrigger className="w-full sm:w-[200px]">
                <SelectValue placeholder="Select Base" />
              </SelectTrigger>
              <SelectContent>
                {user?.role === "admin" && <SelectItem value="all">All Bases</SelectItem>}
                {availableBases.map((base) => (
                  <SelectItem key={base.id} value={base.id}>
                    {base.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={selectedEquipmentType} onValueChange={setSelectedEquipmentType}>
              <SelectTrigger className="w-full sm:w-[200px]">
                <SelectValue placeholder="Equipment Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Equipment</SelectItem>
                {equipmentTypes.map((type) => (
                  <SelectItem key={type.id} value={type.id}>
                    {type.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Purchases Table */}
      <Card>
        <CardHeader>
          <CardTitle>Purchase Records</CardTitle>
          <CardDescription>
            {filteredPurchases.length} purchase{filteredPurchases.length !== 1 ? "s" : ""} found
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>PO Number</TableHead>
                  <TableHead>Base</TableHead>
                  <TableHead>Equipment</TableHead>
                  <TableHead>Quantity</TableHead>
                  <TableHead>Unit Price</TableHead>
                  <TableHead>Total Amount</TableHead>
                  <TableHead>Supplier</TableHead>
                  <TableHead>Date</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPurchases.map((purchase) => {
                  const base = bases.find((b) => b.id === purchase.baseId)
                  const equipmentType = equipmentTypes.find((et) => et.id === purchase.equipmentTypeId)

                  return (
                    <TableRow key={purchase.id}>
                      <TableCell className="font-medium">{purchase.purchaseOrderNumber}</TableCell>
                      <TableCell>{base?.name}</TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">{equipmentType?.name}</div>
                          <div className="text-sm text-muted-foreground">{equipmentType?.category}</div>
                        </div>
                      </TableCell>
                      <TableCell>{purchase.quantity}</TableCell>
                      <TableCell>${purchase.unitPrice.toLocaleString()}</TableCell>
                      <TableCell className="font-medium">${purchase.totalAmount.toLocaleString()}</TableCell>
                      <TableCell>{purchase.supplier}</TableCell>
                      <TableCell>{new Date(purchase.purchaseDate).toLocaleDateString()}</TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
            {filteredPurchases.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">No purchases found matching your criteria</div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
