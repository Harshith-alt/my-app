"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Package, ArrowUpDown, ShoppingCart, Truck, UserCheck } from "lucide-react"
import { bases, equipmentTypes, purchases, transfers, assignments, expenditures } from "@/lib/mock-data"

interface DashboardMetrics {
  openingBalance: number
  closingBalance: number
  netMovement: number
  purchases: number
  transferIn: number
  transferOut: number
  assigned: number
  expended: number
}

export default function DashboardPage() {
  const { user } = useAuth()
  const [selectedBase, setSelectedBase] = useState<string>("all")
  const [selectedEquipmentType, setSelectedEquipmentType] = useState<string>("all")
  const [dateRange, setDateRange] = useState<string>("30")
  const [metrics, setMetrics] = useState<DashboardMetrics>({
    openingBalance: 0,
    closingBalance: 0,
    netMovement: 0,
    purchases: 0,
    transferIn: 0,
    transferOut: 0,
    assigned: 0,
    expended: 0,
  })

  // Filter bases based on user role
  const availableBases = user?.role === "admin" ? bases : bases.filter((base) => base.id === user?.baseId)

  useEffect(() => {
    // Calculate metrics based on filters
    const calculateMetrics = () => {
      // Mock calculation - in real app, this would be API calls
      const baseFilter = selectedBase === "all" ? null : selectedBase
      const equipmentFilter = selectedEquipmentType === "all" ? null : selectedEquipmentType

      // Filter data based on user permissions
      let filteredPurchases = purchases
      let filteredTransfers = transfers
      const filteredAssignments = assignments
      const filteredExpenditures = expenditures

      if (user?.role !== "admin" && user?.baseId) {
        filteredPurchases = purchases.filter((p) => p.baseId === user.baseId)
        filteredTransfers = transfers.filter((t) => t.fromBaseId === user.baseId || t.toBaseId === user.baseId)
      }

      if (baseFilter) {
        filteredPurchases = filteredPurchases.filter((p) => p.baseId === baseFilter)
        filteredTransfers = filteredTransfers.filter((t) => t.fromBaseId === baseFilter || t.toBaseId === baseFilter)
      }

      if (equipmentFilter) {
        filteredPurchases = filteredPurchases.filter((p) => p.equipmentTypeId === equipmentFilter)
        filteredTransfers = filteredTransfers.filter((t) => t.equipmentTypeId === equipmentFilter)
      }

      const totalPurchases = filteredPurchases.reduce((sum, p) => sum + p.quantity, 0)
      const totalTransferIn = filteredTransfers
        .filter((t) => t.status === "completed" && (baseFilter ? t.toBaseId === baseFilter : true))
        .reduce((sum, t) => sum + t.quantity, 0)
      const totalTransferOut = filteredTransfers
        .filter((t) => t.status === "completed" && (baseFilter ? t.fromBaseId === baseFilter : true))
        .reduce((sum, t) => sum + t.quantity, 0)
      const totalAssigned = filteredAssignments.filter((a) => a.status === "active").length
      const totalExpended = filteredExpenditures.length

      const netMovement = totalPurchases + totalTransferIn - totalTransferOut
      const openingBalance = 100 // Mock opening balance
      const closingBalance = openingBalance + netMovement - totalAssigned - totalExpended

      setMetrics({
        openingBalance,
        closingBalance,
        netMovement,
        purchases: totalPurchases,
        transferIn: totalTransferIn,
        transferOut: totalTransferOut,
        assigned: totalAssigned,
        expended: totalExpended,
      })
    }

    calculateMetrics()
  }, [selectedBase, selectedEquipmentType, dateRange, user])

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">Military Asset Management Overview</p>
        </div>
        <Badge variant="outline" className="text-sm">
          {user?.role?.replace("_", " ").toUpperCase()}
        </Badge>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <Select value={selectedBase} onValueChange={setSelectedBase}>
          <SelectTrigger className="w-full sm:w-[200px]">
            <SelectValue placeholder="Select Base" />
          </SelectTrigger>
          <SelectContent>
            {user?.role === "admin" && <SelectItem value="all">All Bases</SelectItem>}
            {availableBases.map((base) => (
              <SelectItem key={base.id} value={base.id}>
                {base.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={selectedEquipmentType} onValueChange={setSelectedEquipmentType}>
          <SelectTrigger className="w-full sm:w-[200px]">
            <SelectValue placeholder="Equipment Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Equipment</SelectItem>
            {equipmentTypes.map((type) => (
              <SelectItem key={type.id} value={type.id}>
                {type.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={dateRange} onValueChange={setDateRange}>
          <SelectTrigger className="w-full sm:w-[150px]">
            <SelectValue placeholder="Date Range" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7">Last 7 days</SelectItem>
            <SelectItem value="30">Last 30 days</SelectItem>
            <SelectItem value="90">Last 90 days</SelectItem>
            <SelectItem value="365">Last year</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Key Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Opening Balance</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.openingBalance}</div>
            <p className="text-xs text-muted-foreground">Assets at period start</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Closing Balance</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.closingBalance}</div>
            <p className="text-xs text-muted-foreground">Current available assets</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Net Movement</CardTitle>
            <ArrowUpDown className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="ghost" className="p-0 h-auto">
                  <div className="text-2xl font-bold text-left">{metrics.netMovement}</div>
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Net Movement Breakdown</DialogTitle>
                  <DialogDescription>Detailed view of asset movements</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="flex items-center gap-2">
                      <ShoppingCart className="h-4 w-4" />
                      Purchases
                    </span>
                    <span className="font-bold text-green-600">+{metrics.purchases}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="flex items-center gap-2">
                      <Truck className="h-4 w-4" />
                      Transfer In
                    </span>
                    <span className="font-bold text-green-600">+{metrics.transferIn}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="flex items-center gap-2">
                      <Truck className="h-4 w-4" />
                      Transfer Out
                    </span>
                    <span className="font-bold text-red-600">-{metrics.transferOut}</span>
                  </div>
                  <hr />
                  <div className="flex justify-between items-center font-bold">
                    <span>Net Movement</span>
                    <span>{metrics.netMovement}</span>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
            <p className="text-xs text-muted-foreground">Click to view breakdown</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Assigned</CardTitle>
            <UserCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{metrics.assigned}</div>
            <p className="text-xs text-muted-foreground">Assets currently assigned</p>
          </CardContent>
        </Card>
      </div>

      {/* Additional Metrics */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest asset movements and assignments</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium">Purchase Order Completed</p>
                  <p className="text-xs text-muted-foreground">50 M4A1 Carbines - Fort Liberty</p>
                </div>
                <span className="text-xs text-muted-foreground">2h ago</span>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium">Transfer Approved</p>
                  <p className="text-xs text-muted-foreground">10 Night Vision Goggles to Camp Pendleton</p>
                </div>
                <span className="text-xs text-muted-foreground">4h ago</span>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium">Asset Assignment</p>
                  <p className="text-xs text-muted-foreground">HMMWV assigned to Special Operations</p>
                </div>
                <span className="text-xs text-muted-foreground">6h ago</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Expenditure Summary</CardTitle>
            <CardDescription>Assets expended by category</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span>Training</span>
                <div className="flex items-center gap-2">
                  <div className="w-20 h-2 bg-gray-200 rounded-full">
                    <div className="w-3/4 h-2 bg-blue-500 rounded-full"></div>
                  </div>
                  <span className="text-sm font-medium">{Math.floor(metrics.expended * 0.6)}</span>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span>Operations</span>
                <div className="flex items-center gap-2">
                  <div className="w-20 h-2 bg-gray-200 rounded-full">
                    <div className="w-1/2 h-2 bg-green-500 rounded-full"></div>
                  </div>
                  <span className="text-sm font-medium">{Math.floor(metrics.expended * 0.3)}</span>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span>Maintenance</span>
                <div className="flex items-center gap-2">
                  <div className="w-20 h-2 bg-gray-200 rounded-full">
                    <div className="w-1/4 h-2 bg-orange-500 rounded-full"></div>
                  </div>
                  <span className="text-sm font-medium">{Math.floor(metrics.expended * 0.1)}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
