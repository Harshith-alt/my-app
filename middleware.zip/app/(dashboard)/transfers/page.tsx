"use client"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Plus, Search, ArrowRight, Clock, CheckCircle, XCircle, Truck } from "lucide-react"
import { bases, equipmentTypes, transfers } from "@/lib/mock-data"
import { hasPermission } from "@/lib/rbac"

export default function TransfersPage() {
  const { user } = useAuth()
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedStatus, setSelectedStatus] = useState<string>("all")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [newTransfer, setNewTransfer] = useState({
    fromBaseId: "",
    toBaseId: "",
    equipmentTypeId: "",
    quantity: "",
    transferDate: "",
    reason: "",
  })

  // Check permissions
  const canWrite = hasPermission(user?.role as any, "transfers", "write")

  // Filter transfers based on user role and permissions
  const filteredTransfers = transfers.filter((transfer) => {
    // Role-based filtering
    if (user?.role !== "admin" && user?.baseId) {
      if (transfer.fromBaseId !== user.baseId && transfer.toBaseId !== user.baseId) {
        return false
      }
    }

    // Search filter
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase()
      const equipmentType = equipmentTypes.find((et) => et.id === transfer.equipmentTypeId)
      const fromBase = bases.find((b) => b.id === transfer.fromBaseId)
      const toBase = bases.find((b) => b.id === transfer.toBaseId)

      if (
        !transfer.reason.toLowerCase().includes(searchLower) &&
        !equipmentType?.name.toLowerCase().includes(searchLower) &&
        !fromBase?.name.toLowerCase().includes(searchLower) &&
        !toBase?.name.toLowerCase().includes(searchLower)
      ) {
        return false
      }
    }

    // Status filter
    if (selectedStatus !== "all" && transfer.status !== selectedStatus) {
      return false
    }

    return true
  })

  const handleAddTransfer = () => {
    // In a real app, this would make an API call
    console.log("Adding transfer:", newTransfer)
    setIsAddDialogOpen(false)
    setNewTransfer({
      fromBaseId: "",
      toBaseId: "",
      equipmentTypeId: "",
      quantity: "",
      transferDate: "",
      reason: "",
    })
  }

  // Get available bases based on user role
  const availableBases = user?.role === "admin" ? bases : bases.filter((base) => base.id === user?.baseId)

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="h-4 w-4" />
      case "in_transit":
        return <Truck className="h-4 w-4" />
      case "completed":
        return <CheckCircle className="h-4 w-4" />
      case "cancelled":
        return <XCircle className="h-4 w-4" />
      default:
        return null
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "in_transit":
        return "bg-blue-100 text-blue-800"
      case "completed":
        return "bg-green-100 text-green-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Transfers</h1>
          <p className="text-muted-foreground">Manage asset transfers between military bases</p>
        </div>
        {canWrite && (
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Request Transfer
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Request Asset Transfer</DialogTitle>
                <DialogDescription>Request transfer of assets between bases</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="fromBase">From Base</Label>
                    <Select
                      value={newTransfer.fromBaseId}
                      onValueChange={(value) => setNewTransfer({ ...newTransfer, fromBaseId: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select source base" />
                      </SelectTrigger>
                      <SelectContent>
                        {availableBases.map((base) => (
                          <SelectItem key={base.id} value={base.id}>
                            {base.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="toBase">To Base</Label>
                    <Select
                      value={newTransfer.toBaseId}
                      onValueChange={(value) => setNewTransfer({ ...newTransfer, toBaseId: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select destination base" />
                      </SelectTrigger>
                      <SelectContent>
                        {bases
                          .filter((base) => base.id !== newTransfer.fromBaseId)
                          .map((base) => (
                            <SelectItem key={base.id} value={base.id}>
                              {base.name}
                            </SelectItem>
                          ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="equipment">Equipment Type</Label>
                    <Select
                      value={newTransfer.equipmentTypeId}
                      onValueChange={(value) => setNewTransfer({ ...newTransfer, equipmentTypeId: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select equipment" />
                      </SelectTrigger>
                      <SelectContent>
                        {equipmentTypes.map((type) => (
                          <SelectItem key={type.id} value={type.id}>
                            {type.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="quantity">Quantity</Label>
                    <Input
                      id="quantity"
                      type="number"
                      value={newTransfer.quantity}
                      onChange={(e) => setNewTransfer({ ...newTransfer, quantity: e.target.value })}
                      placeholder="Enter quantity"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="transferDate">Transfer Date</Label>
                  <Input
                    id="transferDate"
                    type="date"
                    value={newTransfer.transferDate}
                    onChange={(e) => setNewTransfer({ ...newTransfer, transferDate: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="reason">Reason for Transfer</Label>
                  <Textarea
                    id="reason"
                    value={newTransfer.reason}
                    onChange={(e) => setNewTransfer({ ...newTransfer, reason: e.target.value })}
                    placeholder="Enter reason for transfer"
                    rows={3}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="submit" onClick={handleAddTransfer}>
                  Request Transfer
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Filters</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search transfers..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="w-full sm:w-[200px]">
                <SelectValue placeholder="Filter by Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="in_transit">In Transit</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Transfers Table */}
      <Card>
        <CardHeader>
          <CardTitle>Transfer Records</CardTitle>
          <CardDescription>
            {filteredTransfers.length} transfer{filteredTransfers.length !== 1 ? "s" : ""} found
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Transfer Route</TableHead>
                  <TableHead>Equipment</TableHead>
                  <TableHead>Quantity</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Reason</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTransfers.map((transfer) => {
                  const fromBase = bases.find((b) => b.id === transfer.fromBaseId)
                  const toBase = bases.find((b) => b.id === transfer.toBaseId)
                  const equipmentType = equipmentTypes.find((et) => et.id === transfer.equipmentTypeId)

                  return (
                    <TableRow key={transfer.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{fromBase?.name}</span>
                          <ArrowRight className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium">{toBase?.name}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">{equipmentType?.name}</div>
                          <div className="text-sm text-muted-foreground">{equipmentType?.category}</div>
                        </div>
                      </TableCell>
                      <TableCell>{transfer.quantity}</TableCell>
                      <TableCell>{new Date(transfer.transferDate).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <Badge className={`${getStatusColor(transfer.status)} flex items-center gap-1 w-fit`}>
                          {getStatusIcon(transfer.status)}
                          {transfer.status.replace("_", " ").toUpperCase()}
                        </Badge>
                      </TableCell>
                      <TableCell className="max-w-xs">
                        <div className="truncate" title={transfer.reason}>
                          {transfer.reason}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          {transfer.status === "pending" && canWrite && (
                            <>
                              <Button size="sm" variant="outline">
                                Approve
                              </Button>
                              <Button size="sm" variant="outline">
                                Reject
                              </Button>
                            </>
                          )}
                          {transfer.status === "in_transit" && canWrite && (
                            <Button size="sm" variant="outline">
                              Mark Complete
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
            {filteredTransfers.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">No transfers found matching your criteria</div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
