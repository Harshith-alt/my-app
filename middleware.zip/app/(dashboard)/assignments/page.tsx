"use client"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, UserCheck, AlertTriangle, Trash2 } from "lucide-react"
import { assignments, expenditures } from "@/lib/mock-data"
import { hasPermission } from "@/lib/rbac"

export default function AssignmentsPage() {
  const { user } = useAuth()
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedStatus, setSelectedStatus] = useState<string>("all")
  const [isAssignDialogOpen, setIsAssignDialogOpen] = useState(false)
  const [isExpendDialogOpen, setIsExpendDialogOpen] = useState(false)
  const [newAssignment, setNewAssignment] = useState({
    assetId: "",
    assignedToName: "",
    assignedToRank: "",
    assignedToUnit: "",
    assignmentDate: "",
    expectedReturnDate: "",
    assignmentReason: "",
  })
  const [newExpenditure, setNewExpenditure] = useState({
    assetId: "",
    expenditureDate: "",
    expenditureReason: "",
    expenditureType: "",
  })

  // Check permissions
  const canWrite = hasPermission(user?.role as any, "assignments", "write")

  // Filter assignments based on user role and permissions
  const filteredAssignments = assignments.filter((assignment) => {
    // Search filter
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase()
      if (
        !assignment.assignedToName.toLowerCase().includes(searchLower) &&
        !assignment.assignedToRank.toLowerCase().includes(searchLower) &&
        !assignment.assignedToUnit.toLowerCase().includes(searchLower) &&
        !assignment.assignmentReason.toLowerCase().includes(searchLower)
      ) {
        return false
      }
    }

    // Status filter
    if (selectedStatus !== "all" && assignment.status !== selectedStatus) {
      return false
    }

    return true
  })

  // Filter expenditures
  const filteredExpenditures = expenditures.filter((expenditure) => {
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase()
      if (
        !expenditure.expenditureReason.toLowerCase().includes(searchLower) &&
        !expenditure.expenditureType.toLowerCase().includes(searchLower)
      ) {
        return false
      }
    }
    return true
  })

  const handleAddAssignment = () => {
    console.log("Adding assignment:", newAssignment)
    setIsAssignDialogOpen(false)
    setNewAssignment({
      assetId: "",
      assignedToName: "",
      assignedToRank: "",
      assignedToUnit: "",
      assignmentDate: "",
      expectedReturnDate: "",
      assignmentReason: "",
    })
  }

  const handleAddExpenditure = () => {
    console.log("Adding expenditure:", newExpenditure)
    setIsExpendDialogOpen(false)
    setNewExpenditure({
      assetId: "",
      expenditureDate: "",
      expenditureReason: "",
      expenditureType: "",
    })
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800"
      case "returned":
        return "bg-blue-100 text-blue-800"
      case "overdue":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getExpenditureTypeColor = (type: string) => {
    switch (type) {
      case "training":
        return "bg-blue-100 text-blue-800"
      case "operation":
        return "bg-green-100 text-green-800"
      case "maintenance":
        return "bg-yellow-100 text-yellow-800"
      case "disposal":
        return "bg-gray-100 text-gray-800"
      case "lost":
        return "bg-red-100 text-red-800"
      case "damaged":
        return "bg-orange-100 text-orange-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Assignments & Expenditures</h1>
          <p className="text-muted-foreground">Manage asset assignments to personnel and track expenditures</p>
        </div>
        <div className="flex gap-2">
          {canWrite && (
            <>
              <Dialog open={isAssignDialogOpen} onOpenChange={setIsAssignDialogOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <UserCheck className="mr-2 h-4 w-4" />
                    Assign Asset
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[600px]">
                  <DialogHeader>
                    <DialogTitle>Assign Asset</DialogTitle>
                    <DialogDescription>Assign an asset to military personnel</DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="assetId">Asset</Label>
                      <Select
                        value={newAssignment.assetId}
                        onValueChange={(value) => setNewAssignment({ ...newAssignment, assetId: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select asset" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">M4A1 Carbine - M4-001-2024</SelectItem>
                          <SelectItem value="2">M9 Pistol - M9-001-2024</SelectItem>
                          <SelectItem value="3">HMMWV - HMMWV-001-2024</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="assignedToName">Personnel Name</Label>
                        <Input
                          id="assignedToName"
                          value={newAssignment.assignedToName}
                          onChange={(e) => setNewAssignment({ ...newAssignment, assignedToName: e.target.value })}
                          placeholder="Enter full name"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="assignedToRank">Rank</Label>
                        <Input
                          id="assignedToRank"
                          value={newAssignment.assignedToRank}
                          onChange={(e) => setNewAssignment({ ...newAssignment, assignedToRank: e.target.value })}
                          placeholder="Enter rank"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="assignedToUnit">Unit</Label>
                      <Input
                        id="assignedToUnit"
                        value={newAssignment.assignedToUnit}
                        onChange={(e) => setNewAssignment({ ...newAssignment, assignedToUnit: e.target.value })}
                        placeholder="Enter unit designation"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="assignmentDate">Assignment Date</Label>
                        <Input
                          id="assignmentDate"
                          type="date"
                          value={newAssignment.assignmentDate}
                          onChange={(e) => setNewAssignment({ ...newAssignment, assignmentDate: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="expectedReturnDate">Expected Return Date</Label>
                        <Input
                          id="expectedReturnDate"
                          type="date"
                          value={newAssignment.expectedReturnDate}
                          onChange={(e) => setNewAssignment({ ...newAssignment, expectedReturnDate: e.target.value })}
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="assignmentReason">Assignment Reason</Label>
                      <Textarea
                        id="assignmentReason"
                        value={newAssignment.assignmentReason}
                        onChange={(e) => setNewAssignment({ ...newAssignment, assignmentReason: e.target.value })}
                        placeholder="Enter reason for assignment"
                        rows={3}
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button type="submit" onClick={handleAddAssignment}>
                      Assign Asset
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>

              <Dialog open={isExpendDialogOpen} onOpenChange={setIsExpendDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline">
                    <Trash2 className="mr-2 h-4 w-4" />
                    Record Expenditure
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[600px]">
                  <DialogHeader>
                    <DialogTitle>Record Asset Expenditure</DialogTitle>
                    <DialogDescription>Record the expenditure or disposal of an asset</DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="expendAssetId">Asset</Label>
                      <Select
                        value={newExpenditure.assetId}
                        onValueChange={(value) => setNewExpenditure({ ...newExpenditure, assetId: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select asset" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">M4A1 Carbine - M4-001-2024</SelectItem>
                          <SelectItem value="2">M9 Pistol - M9-001-2024</SelectItem>
                          <SelectItem value="3">HMMWV - HMMWV-001-2024</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="expenditureDate">Expenditure Date</Label>
                        <Input
                          id="expenditureDate"
                          type="date"
                          value={newExpenditure.expenditureDate}
                          onChange={(e) => setNewExpenditure({ ...newExpenditure, expenditureDate: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="expenditureType">Expenditure Type</Label>
                        <Select
                          value={newExpenditure.expenditureType}
                          onValueChange={(value) => setNewExpenditure({ ...newExpenditure, expenditureType: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="training">Training</SelectItem>
                            <SelectItem value="operation">Operation</SelectItem>
                            <SelectItem value="maintenance">Maintenance</SelectItem>
                            <SelectItem value="disposal">Disposal</SelectItem>
                            <SelectItem value="lost">Lost</SelectItem>
                            <SelectItem value="damaged">Damaged</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="expenditureReason">Expenditure Reason</Label>
                      <Textarea
                        id="expenditureReason"
                        value={newExpenditure.expenditureReason}
                        onChange={(e) => setNewExpenditure({ ...newExpenditure, expenditureReason: e.target.value })}
                        placeholder="Enter detailed reason for expenditure"
                        rows={3}
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button type="submit" onClick={handleAddExpenditure}>
                      Record Expenditure
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </>
          )}
        </div>
      </div>

      <Tabs defaultValue="assignments" className="space-y-6">
        <TabsList>
          <TabsTrigger value="assignments">Assignments</TabsTrigger>
          <TabsTrigger value="expenditures">Expenditures</TabsTrigger>
        </TabsList>

        <TabsContent value="assignments" className="space-y-6">
          {/* Filters */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Filters</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Search assignments..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger className="w-full sm:w-[200px]">
                    <SelectValue placeholder="Filter by Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="returned">Returned</SelectItem>
                    <SelectItem value="overdue">Overdue</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Assignments Table */}
          <Card>
            <CardHeader>
              <CardTitle>Asset Assignments</CardTitle>
              <CardDescription>
                {filteredAssignments.length} assignment{filteredAssignments.length !== 1 ? "s" : ""} found
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Asset</TableHead>
                      <TableHead>Assigned To</TableHead>
                      <TableHead>Unit</TableHead>
                      <TableHead>Assignment Date</TableHead>
                      <TableHead>Expected Return</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Reason</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredAssignments.map((assignment) => (
                      <TableRow key={assignment.id}>
                        <TableCell>
                          <div className="font-medium">Asset #{assignment.assetId}</div>
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{assignment.assignedToName}</div>
                            <div className="text-sm text-muted-foreground">{assignment.assignedToRank}</div>
                          </div>
                        </TableCell>
                        <TableCell>{assignment.assignedToUnit}</TableCell>
                        <TableCell>{new Date(assignment.assignmentDate).toLocaleDateString()}</TableCell>
                        <TableCell>
                          {assignment.expectedReturnDate
                            ? new Date(assignment.expectedReturnDate).toLocaleDateString()
                            : "N/A"}
                        </TableCell>
                        <TableCell>
                          <Badge className={`${getStatusColor(assignment.status)} flex items-center gap-1 w-fit`}>
                            {assignment.status === "overdue" && <AlertTriangle className="h-3 w-3" />}
                            {assignment.status.toUpperCase()}
                          </Badge>
                        </TableCell>
                        <TableCell className="max-w-xs">
                          <div className="truncate" title={assignment.assignmentReason}>
                            {assignment.assignmentReason}
                          </div>
                        </TableCell>
                        <TableCell>
                          {assignment.status === "active" && canWrite && (
                            <Button size="sm" variant="outline">
                              Mark Returned
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                {filteredAssignments.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    No assignments found matching your criteria
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="expenditures" className="space-y-6">
          {/* Expenditures Table */}
          <Card>
            <CardHeader>
              <CardTitle>Asset Expenditures</CardTitle>
              <CardDescription>
                {filteredExpenditures.length} expenditure{filteredExpenditures.length !== 1 ? "s" : ""} found
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Asset</TableHead>
                      <TableHead>Expenditure Date</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Reason</TableHead>
                      <TableHead>Authorized By</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredExpenditures.map((expenditure) => (
                      <TableRow key={expenditure.id}>
                        <TableCell>
                          <div className="font-medium">Asset #{expenditure.assetId}</div>
                        </TableCell>
                        <TableCell>{new Date(expenditure.expenditureDate).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <Badge className={`${getExpenditureTypeColor(expenditure.expenditureType)} w-fit`}>
                            {expenditure.expenditureType.toUpperCase()}
                          </Badge>
                        </TableCell>
                        <TableCell className="max-w-xs">
                          <div className="truncate" title={expenditure.expenditureReason}>
                            {expenditure.expenditureReason}
                          </div>
                        </TableCell>
                        <TableCell>User #{expenditure.authorizedBy}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                {filteredExpenditures.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    No expenditures found matching your criteria
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
